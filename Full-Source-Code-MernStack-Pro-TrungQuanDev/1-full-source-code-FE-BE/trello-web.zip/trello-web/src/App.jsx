import Board from '~/pages/Boards/_id'

function App() {
  return (
    <>
      {/* React Router Dom /boards /boards/{board_id} */}
      {/* Board Details */}
      <Board />
    </>
  )
}

export default App
